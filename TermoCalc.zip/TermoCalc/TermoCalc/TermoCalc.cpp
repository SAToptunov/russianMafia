﻿// TermoCalc.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <windows.h>
#include <algorithm>
#include <string>
#include <vector>
#include <map>
#include <cmath>
using namespace std;
int main()
{
	string a;
	cin >> a;
   cout << "~~~~~~~~~~~~~~~~                      Hello! We are glad to see you on our calculator!                  ~~~~~~~~~~~~~~~~          " << endl ;
   cout << "                                                     WHAT IT CAN DO?               " << endl;
   cout << "This calculator can find amount of heat, mass or make a chemistry equation" << endl;
   cout << "You just need to select the option you are interested in and enter the elements and quantities" << endl;
   cout << "Please, note that all input quantities must be in the SI sistem! You can only change the unit of measurement in the answer!" << endl;
   //tablitza na Mendeleev s atom.massa
   double Na = 6.02 * pow(10, 23); //chislo Avogadro
   map<string, double> tablM;
   tablM["H"] = 1.00794;
   tablM["Li"] =6.941;
   tablM["Na"] = 22.9898;
   tablM["K"] =39.102 ;
   tablM["Cu"] = 63.546;
   tablM["Rb"] = 85.47;
   tablM["Cs"] =107.868 ;
   tablM["Fr"] = 132.905;
   tablM["Be"] = 196.967;
   tablM["Mg"] = 24.305;
   tablM["Ca"] = 40.08;
   tablM["Zn"] = 65.37;
   tablM["Sr"] =87.62 ;
   tablM["Cd"] = 112.40;
   tablM["Ba"] = 137.34;
   tablM["Hg"] = 200.59;
   tablM["Ra"] = 226;
   tablM["B"] = 10.811;
   tablM["Al"] = 26.9815;
   tablM["Sc"] = 44.956;
   tablM["Ga"] =69.72 ;
   tablM["Y"] = 88.905;
   tablM["In"] = 114.82;
   tablM["Tl"] = 204.37;
   tablM["C"] =12.01115 ;
   tablM["Si"] =28.086 ;
   tablM["Ti"] = 47.90;
   tablM["Ge"] = 72.59;
   tablM["Zr"] = 91.22;
   tablM["Sn"] = 118.69;
   tablM["Hf"] = 178.49;
   tablM["Pb"] = 207.19;
   tablM["N"] = 14.0067;
   tablM["P"] =30.9738 ;
   tablM["V"] = 50.942;
   tablM["As"] = 74.9216;
   tablM["Nb"] = 92.906;
   tablM["Sb"] = 121.75;
   tablM["Ta"] = 180.948;
   tablM["Bi"] =208.980 ;
   tablM["O"] = 15.9994 ;
   tablM["S"] = 32.064;
   tablM["Cr"] = 51.996;
   tablM["Se"] = 78.96;
   tablM["Mo"] = 95.94;
   tablM["Te"] = 127.60;
   tablM["W"] = 183.85;
   tablM["Po"] = 208.9824;
   tablM["F"] = 18.9984;
   tablM["Cl"] = 35.453;
   tablM["Mn"] = 54.9380;
   tablM["Br"] = 79.904;
   tablM["Tc"] = 97.9072;
   tablM["I"] = 126.9044;
   tablM["Re"] = 186.2;
   tablM["At"] = 210;
   tablM["He"] = 4.0026;
   tablM["Ne"] = 20.179;
   tablM["Ar"] = 39.948;
   tablM["Fe"] = 55.847;
   tablM["Kr"] = 83.80;
   tablM["Ru"] = 101.07;
   tablM["Xe"] = 131.30;
   tablM["Os"] = 190.2;
   tablM["Rn"] = 222;
   tablM["Co"] = 58.9330;
   tablM["Rh"] = 102.905;
   tablM["Ir"] = 192.2;
   tablM["Ni"] = 58.71;
  



}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
